from django.db import models
from django.utils import timezone
from django.core.exceptions import ValidationError
import datetime
from django.contrib.auth.models import AbstractUser, BaseUserManager, PermissionsMixin, AbstractBaseUser

# 모델의 __str__에 적용할 함수
ignore_field = set(["created_by", "updated_at", "updated_by", "created_at", "status"])
def make_model_string(self):
    field_values = []
    for field in self._meta.get_fields():
        try:
            field_name = field.attname
            if field_name in ignore_field:
                continue
            field_values.append(str(self.__getattribute__(field.attname)))
        except:
            pass
    return '-'.join(field_values)

# 모든 모델에 적용할 기본정보
class CommonInfo(models.Model):
    created_by = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_by = models.TextField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    STATUS_CHOICE = (
        # (CODE, "DESCRIPTION"),
        (2, "Update"),
        (1, "Pending Updated"),
        (0, "Done"),
        (-1, "Pending Deleted"),
        (-2, "Delete"),
    )
    status = models.IntegerField(choices=STATUS_CHOICE, default=0)

    def save(self, *args, **kwargs):
        # ID가 없을시, 즉 처음 생성될때
        if not self.id:
            if not self.created_at:
                self.created_at = timezone.now()
        self.updated_at = timezone.now()
        return super(CommonInfo, self).save(*args, **kwargs)

    def __str__(self):
        return make_model_string(self)

    # 상속가능하도록 설정
    class Meta:
        abstract = True

class CustomUser(AbstractUser):
    # 일부 불필요하다고 생각되는 것들 제거
    groups = None
    first_name = None
    last_name = None
    date_joined = None

    # 관리자 여부
    is_staff = models.BooleanField(default=False)

    # 아이디로 사용할 이메일
    # email = models.EmailField('email address', unique=True)
    AbstractUser.username = models.EmailField('email address', unique=True)

    # 암호화를 위한 salt
    # salt = models.CharField(max_length=127)
    
    # 간단한 메모
    comment = models.TextField(blank=True, null=True)

    # 관리자가 관리할 수 있도록 설정
    AUTH_CHOICE = (
        # (CODE, "DESCRIPTION"),
        (-1, "Rejected"),
        (0, "Wait"),
        (1, "Authorized"),
    )
    is_authorized = models.IntegerField(choices=AUTH_CHOICE, default=0, blank=True, null=True)

    # 반드시 필요한 필드
    # REQUIRED_FIELDS = ['username', 'password']
    def __str__(self):
        return f'{self.username}'

# 확장자 제한
def validate_file_extension(value):
    import os
    ext = os.path.splitext(value.name)[1]
    valid_extensions = ['.jpg', '.jpeg', '.png']
    if not ext in valid_extensions:
        raise ValidationError(u'File not supported!')

# 일기장에 쓸 날씨에 관한 모델
class Weather(CommonInfo):
    name = models.CharField(max_length=127, unique=True)
    icon = models.FileField(upload_to=f'weather/{name}', validators=[validate_file_extension], blank=True, null=True)

# 유저별로 업로드한 파일을 따로 정리하기 위해
def user_directory_path(instance, filename):
    return f'user_{instance.user.id}/{filename}'

# 일기장에 관한 모델
from .emotion import *
class DailyNote(CommonInfo):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, to_field='id', db_column='user', related_name='user')
    title = models.TextField()
    content = models.TextField()
    weather = models.ForeignKey(Weather, on_delete=models.DO_NOTHING, to_field='id', db_column='weather', related_name='weather')
    upload = models.FileField(upload_to=user_directory_path, validators=[validate_file_extension], blank=True, null=True)
    emotion = models.TextField(blank=True, null=True)

    def save(self, *args, **kwargs):
        self.emotion = classify(self.content)['class_name']
        super().save(*args, **kwargs)

# 추천 컨텐츠에 관한 모델
class RecommendationContent(CommonInfo):
    emotion = models.CharField(max_length=127)
    mention = models.TextField()
    link = models.TextField()
    image = models.FileField(upload_to=lambda instance, filename: f'content/{instance.image}', validators=[validate_file_extension], blank=True, null=True)