from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from .views import *

urlpatterns = [
    path('write_note/<slug:year>/<slug:month>/<slug:day>', write_note, name='write_note'),
    path('my_emotion', my_emotion, name='my_emotion'),
    path('emotion_rhythm', emotion_rhythm, name='emotion_rhythm'),
    path('signup', signup, name='signup'),
    path('signin', signin, name='signin'),
    path('signout', auth_views.logout_then_login, {'login_url': 'signin'}, name='signout'),
    path('calendar', calendar, name='calendar'),
    path('view_note/<slug:note_id>', view_note, name='view_note'),
    path('edit_note/<slug:note_id>', edit_note, name='edit_note'),
    path('delete_note/<slug:note_id>', delete_note, name='delete_note'),
]


