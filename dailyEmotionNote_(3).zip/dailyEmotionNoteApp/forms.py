from django.forms import ModelForm
from .models import *

# 회원가입 폼
class CustomUserForm(ModelForm):
    class Meta:
        model = CustomUser
        fields = '__all__'
        labels = {
            "username": "아이디",
            "password": "패스워드",
        }

    def save(self, commit=True):
        # Save the provided password in hashed format
        user = super(CustomUserForm, self).save(commit=False)
        user.set_password(self.cleaned_data["password"])
        user.is_active = True
        if commit:
            user.save()
        return user

# 일기장 폼
class DailyNoteForm(ModelForm):
    class Meta:
        model = DailyNote
        fields = '__all__'
        exclude = ['status']
        labels = {
            "title": "제목",
            "content": "내용",
            "upload": "파일",
            "weather": "날씨",
            "emotion": "감정",
        }