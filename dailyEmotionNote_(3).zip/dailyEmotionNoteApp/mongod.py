import random

import pymongo
from statistics import mean
# http://www.querymongo.com/
from bson.codec_options import CodecOptions


class MongoDb:
    ASCENDING = pymongo.ASCENDING
    DESCENDING = pymongo.DESCENDING

    def __init__(self, database, collectionName=None):
        self.connection = pymongo.MongoClient('13.209.112.192', 27017, connect=False)
        self.database = self.connection.get_database("admin")
        self.database.authenticate('jhyunetp1', 'jnh1101')
        self.database = self.connection.get_database(database)
        options = CodecOptions(tz_aware=True)
        if collectionName != None:
            self.collection = self.database.get_collection(collectionName, codec_options=options)

    def _getCollection(self, collectionName):
        return self.database.get_collection(collectionName)

    def findByCollection(self, collectionName, query={}):
        return self._getCollection(collectionName).find(query)

    def findMaxByCollection(self, collectionName, query={}, maxColumn=""):
        return self._getCollection(collectionName).find(query).sort(maxColumn, -1).limit(1)

    def insertDocument(self, collectionName, documents=[]):
        if type(documents).__name__ == 'dict':
            return self._getCollection(collectionName).insert_one(documents)
        else:
            return self._getCollection(collectionName).insert_many(documents)

    def createIndexIfNotExist(self, collection_obj, indices, isUnique=True):
        if not pymongo.IndexModel(indices).document["name"] in collection_obj.index_information().keys():
            collection_obj.create_index(indices, unique=isUnique)

    def popByCollection(self, collectionName, query={}):
        return self._getCollection(collectionName).find(query)


def roundTwoDigits(a):
    return (round(a, 2))


def seperateByComma(*args):
    args = list(map(str, args))
    args[-1] = args[-1].replace("[", "").replace("]", "")
    return ",".join(args)


def getBestDocument(inputList, eachMonth, howmany, min_result_threshold, stabilityFactor):
    maxV = -float("inf")
    for document in inputList:
        resultPeriodSumDocument = [0] * 28
        thisDocumentResultValues = [j for i, j in sorted(document["RESULTPERMONTH"].items())]
        resultPeriodSumDocument[eachMonth - 1] = sumWithStabilityFactor(
            thisDocumentResultValues[eachMonth - howmany:eachMonth], stabilityFactor)
        if maxV < resultPeriodSumDocument[
            eachMonth - 1]:  # document["RESULT_MIN"] > min_result_threshold and maxV < resultPeriodSumDocument[eachMonth-1]
            maxV = max(resultPeriodSumDocument[eachMonth - 1], maxV)
            bestDocument = thisDocumentResultValues
    return maxV, maxV / howmany, mean(bestDocument[eachMonth:]), bestDocument[eachMonth - 1], bestDocument[eachMonth:]


def sumWithStabilityFactor(inputList, stabilityFactor):
    positiveSum = sum(filter(lambda x: x >= 0, inputList))
    negativeList = list(filter(lambda x: x < 0, inputList))
    # negativeList = list(map(lambda x : (x ** 2) * stabilityFactor, inputList))
    negativeSum = sum(negativeList) * stabilityFactor
    return positiveSum + negativeSum


def forwardAnalysis(inputList):
    import time
    mongodb = MongoDb("jessica")
    min_result_threshold = -100
    count = 0
    maximum_month = 28
    f = open('output.csv', 'a')
    f2 = open('outputAlongStabFactor.csv', 'a')
    f2.write("nextMonths ")
    f.write("howmany, previousSum, previousMean, nextMean, previousLast, nextValues\n")
    for i in range(10, 100):
        tPrev = time.time()
        nextMonthResultList = []
        stabilityFactor = i * 0.1
        f.write(seperateByComma("factor : ", stabilityFactor) + "\n")
        for howmany in range(3, maximum_month - 1):
            for eachMonth in range(howmany, maximum_month):
                bestDocument = getBestDocument(inputList, eachMonth, howmany, min_result_threshold, stabilityFactor)
                nextMonthResultList.append(bestDocument[-1][0])
                f.write(seperateByComma(howmany, bestDocument).replace("(", "").replace(")", "") + "\n")
        print(mean(nextMonthResultList), time.time() - tPrev)
        f2.write(str(mean(nextMonthResultList)) + "\n")


def changeAllDocumentsOfCollection(inputList):
    document["ARGUMENTS"], document["CODE"] = document["CODE"], document["ARGUMENTS"]
    values = document["RESULTPERMONTH"].values()
    document["RESULT_SUM"] = sum(values)
    document["RESULT_AVG"] = roundTwoDigits(document["RESULT_SUM"] / len(document["RESULTPERMONTH"])) if len(
        document["RESULTPERMONTH"]) != 0 else -1000
    document["RESULT_LEN"] = len(document["RESULTPERMONTH"])
    document["RESULT_MIN"] = min(values) if len(values) != 0 else -1000
    if "buyInfo" in document:
        del document["buyInfo"]
    if "sellInfo" in document:
        del document["sellInfo"]
    try:
        # mongodb.database.get_collection(resultCollectionName).save(document)
        # mongodb.database.get_collection(resultCollectionName + "_" + str(howmany)).find_one_and_replace({u'_id': document["_id"]}, document)
        mongodb.database.get_collection(resultCollectionName + "_" + str(howmany)).insert_one(document)
        # mongodb.database.get_collection(resultCollectionName + "_" + str(howmany)).find_one_and_replace({u'_id': document["_id"]}, document)
        print("inserted")
    except Exception as ex:
        # print(ex)
        mongodb.database.get_collection(resultCollectionName).delete_one({u'_id': document["_id"]})

    # for i in aa:
    #     if i["RESULT_LEN"] != 28:
    #         break
    #     inputList.append(i)
    # print(len(inputList))
    # func(inputList)
    # util.JHLib.multiprocessWithInputList(func, inputList)
    # if len(inputList) == 100000:
    #     inputList.clear()
    # util.JHLib.multiprocessWithInputList(func, inputList)

    # Test 2 insert_many
    # documents = [document.copy()] * 2
    # document["CODE"] = "444444"
    # documents.append(document.copy())
    # mongodb.insertDocument("RESULT", documents)


resultCollectionName = "SIMULATION_RESULT_T_INV_28"
if __name__ == "__main__":
    mongodb = MongoDb("jessica")
    aa = mongodb.findByCollection(resultCollectionName, {})
    # totalCount = (aa.count())
    # print(totalCount)
    import os, sys, copy, math, statistics, datetime

    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import util.JHLib

    inputList = list(aa)
    print(len(inputList))
    forwardAnalysis(inputList)
