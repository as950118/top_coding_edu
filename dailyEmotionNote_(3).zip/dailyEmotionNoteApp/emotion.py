import requests

# This function will pass your text to the machine learning model
# and return the top result with the highest confidence
def classify(text):
    key = "470da790-8f34-11ea-9cce-83c3031cc0de4c88a9d6-a725-44fa-8cae-522222cc6b4a"
    url = "https://machinelearningforkids.co.uk/api/scratch/"+ key + "/classify"

    response = requests.get(url, params={ "data" : text })

    if response.ok:
        responseData = response.json()
        topMatch = responseData[0]
        return topMatch
    else:
        response.raise_for_status()


if __name__ == "__main__":
    # CHANGE THIS to something you want your machine learning model to classify
    demo = classify("The text that you want to test")

    label = demo["class_name"]
    confidence = demo["confidence"]


    # CHANGE THIS to do something different with the result
    print ("result: '%s' with %d%% confidence" % (label, confidence))