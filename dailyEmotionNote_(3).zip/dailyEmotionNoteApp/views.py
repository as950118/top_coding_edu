from .models import *
from .utils import *
from .forms import *
from django.http import JsonResponse
from django.template.response import TemplateResponse
from django.shortcuts import redirect, render
from django.contrib.auth import login, authenticate
# Create your views here.

# 회원가입 뷰
@navsDecorator
def signup(req):
    if req.method == "GET":
        return TemplateResponse(req, template='signup.html', context={}, status=200)
    elif req.method == "POST":
        # 비밀번호 같은지 검사
        if req.POST['password'] != req.POST['password2']:
            return TemplateResponse(req, template='signup.html', context={'error': 'Check Your Password'}, status=200)
        # 회원가입이 잘되면 로그인 페이지로 리다이렉트
        # 회원가입이 안되면 오류내용 반환하고 다시 작성하도록
        POST = req.POST.copy()
        del POST['password2']
        # salt = make_salt()
        # POST['salt'] = salt
        obj = CustomUserForm(POST, req.FILES)
        # 회원가입이 문제없을시
        if obj.is_valid():
            obj.save()
            return redirect('signin')
            # res = JsonResponse({'msg': 'success'})
            # res.status_code = 200
        # 회원가입이 문제있을시
        else:
            error = obj.errors.as_text()
            print(error)
            return TemplateResponse(req, template='signup.html', context={'error': error}, status=200)

# 로그인 뷰
@navsDecorator
def signin(request):
    if request.method == 'GET':
        if request.user.is_authenticated:
            return redirect('calendar')
        else:
            return TemplateResponse(request, "signin.html", {})
    if request.method == 'POST':
        try:
            # salt와 입력받은 암호를 통해 일치하는지 확인
            user = authenticate(request, username=request.POST['username'], password=request.POST['password'])
            if not user:
                user = CustomUser.objects.get(username=request.POST['username'], password=request.POST['password'])
            # 일치한다면 로그인
            login(request, user=user)
            # 로그인이 완료된다면 달력 페이지로 리다이렉트
            return redirect('calendar')
        except Exception as e:
            # 일치하지 않거나 해당하는 아이디가 없다면 오류를 반환
            print(e.args[0])
            return render(request, "signin.html", {})


# 일기장 쓰기 뷰
@navsDecorator
def write_note(req, year, month, day):
    if req.method == "GET":
        weathers = Weather.objects.all()
        context = {}
        context['weathers'] = weathers
        context['year'] = year
        context['month'] = month
        context['day'] = day
        return TemplateResponse(req, template='write_note.html', context=context, status=200)
    elif req.method == "POST":
        POST = req.POST.copy()
        POST['user'] = req.user
        obj = DailyNoteForm(POST, req.FILES)
        # 일기쓰기가 문제없을시
        if obj.is_valid():
            obj = obj.save()
            obj.created_at = timezone.datetime(year=int(year), month=int(month), day=int(day))
            obj.save()
            obj_id = obj.id # 일기장의 id를 넘겨줘서 해당 일기장으로 리다이렉트 할수있도록
            return redirect('view_note', obj_id)
        # 일기쓰기가 문제있을시
        else:
            error = obj.errors.as_text()
            print(error)
            return TemplateResponse(req, template='write_note.html', context={'error': error}, status=200)

# 일기장 읽기 뷰
@navsDecorator
def view_note(req, note_id):
    if req.method == "GET":
        obj = DailyNote.objects.get(id=note_id)
        if not req.user.is_authenticated: # 로그인한 상태가 아니라면 로그인 페이지로 이동
            return redirect('signin')
        userId = req.user.id
        if userId != obj.user.id: # 자기자신의 일기장이 아니라면 달력 페이지로 리다이렉트
            print("permission check")
            return redirect('calendar')
        context = {}
        context['obj'] = obj
        context['year'] = obj.created_at.date().year
        context['month'] = obj.created_at.date().month
        context['day'] = obj.created_at.date().day
        return TemplateResponse(req, template='view_note.html', context=context, status=200)

@navsDecorator
def edit_note(req, note_id):
    obj = DailyNote.objects.get(id=note_id)
    if not req.user.is_authenticated:  # 로그인한 상태가 아니라면 로그인 페이지로 이동
        return redirect('signin')
    userId = req.user.id
    if userId != obj.user.id:  # 자기자신의 일기장이 아니라면 달력 페이지로 리다이렉트
        print("permission check")
        return redirect('calendar')
    context = {}
    context['obj'] = obj
    if req.method == 'GET':
        weathers = Weather.objects.all()
        context['weathers'] = weathers
        context['year'] = obj.created_at.date().year
        context['month'] = obj.created_at.date().month
        context['day'] = obj.created_at.date().day
        return TemplateResponse(req, template='edit_note.html', context=context, status=200)
    else:
        POST = req.POST.copy()
        POST['user'] = req.user
        new_obj = DailyNoteForm(POST, req.FILES)
        # 일기쓰기가 문제없을시
        if new_obj.is_valid():
            # 전에 것을 삭제하고 새롭게 만듬
            obj.delete()
            new_obj = new_obj.save()
            obj_id = new_obj.id  # 일기장의 id를 넘겨줘서 해당 일기장으로 리다이렉트 할수있도록
            return redirect('view_note', obj_id)
        # 일기쓰기가 문제있을시
        else:
            error = new_obj.errors.as_text()
            print(error)
            context['error'] = error
            return TemplateResponse(req, template='edit_note.html', context=context, status=200)

def delete_note(req, note_id):
    if req.method == 'GET':
        obj = DailyNote.objects.filter(id = note_id)
        if obj:
            obj.delete()
        return redirect('calendar')

from dateutil.relativedelta import relativedelta
# 달력 뷰
@navsDecorator
def calendar(req):
    if req.method == "GET":
        year = timezone.localdate().year
        month = timezone.localdate().month
        if 'year' in req.GET:
            year = int(req.GET['year'])
        if 'month' in req.GET:
            month = int(req.GET['month'])
        if not '_auth_user_id' in req.session._session: # 로그인한 상태가 아니라면 로그인 페이지로 이동
            return redirect('signin')
        user_id = req.session._session['_auth_user_id']
        # 달력의 범위내에서 필터링
        from_date = timezone.localtime().replace(year=year, month=month, day=1).date()
        to_date = from_date + relativedelta(months=1)
        objs = DailyNote.objects.filter(user=user_id, created_at__range=(from_date, to_date)).values('id', 'created_at', 'emotion').order_by('created_at')
        # 해당하는 날짜를 찾을 수 있도록 created_at을 day 형태로 변환
        '''
        달력만들기 알고리즘 ;
        1. 어차피 같은 달에 있으므로 편의를 위해 모든 일자는 일(day)로 바꿔줌
        2. 첫번째로 알아야할건 주가 바뀌는, 즉 줄이바뀌는 날, 첫번째 일요일(이하 first)은 계산해줌
        3. 그 후에 바뀌는 날(이하 cur)은 cur%7 == first일 경우에 바꾸는 것으로 설정함
        4. 두번째로 알아야할건 해당 월의 1일이 무슨 요일(이하 day of week, dow)인지
        5. dow를 계산해서 첫번째 줄에 공백을 설정함
        6. 사실 first와 dow는 한번에 구할수있음 => 만약 dow가 5라면 first 는 2일것이기 때문
        7. 몇일에 끝나는지
        8. 몇주까지 있는지
        '''
        dow = from_date.weekday()
        first = 7 - from_date.weekday()
        import calendar
        last = calendar.monthrange(year, month)[1]
        weeks = (last-first)//7
        if objs:
            for obj in objs:
                obj['created_at'] = int(timezone.localtime(obj['created_at']).strftime("%d"))
        contexts = {"objs":list(objs), "dow":dow, "first":first, "last":last, "weeks":weeks, 'year':year, 'month':month}
        return TemplateResponse(req, template='calendar.html', context=contexts, status=200)




# 나의 감정은? 뷰
import random
@navsDecorator
def my_emotion(req):
    if req.method == "GET":
        if not req.user.is_authenticated: # 로그인한 상태가 아니라면 로그인 페이지로 이동
            return redirect('signin')
        userId = req.user.id
        # 오늘 일기가 있는지 검사
        from_date = timezone.localtime().today().date()
        to_date = (timezone.localtime().today() + timezone.timedelta(days=1)).date()
        objs = DailyNote.objects.filter(user=userId, created_at__range=(from_date, to_date))
        # 없다면 달력으로 넘어감
        if not objs:
            year = timezone.localdate().year
            month = timezone.localdate().month
            day = timezone.localdate().day
            return redirect('write_note', year=year, month=month, day=day)
        # 오늘 중에 가장 많은 감정
        df = pd.DataFrame(objs.values()).groupby('emotion').size()
        emotion = max(dict(df))
        # 추천 컨텐츠를 넣어줘야함
        recommendation_contents = RecommendationContent.objects.filter(emotion=emotion).order_by('?').first()
        contexts = {'emotion':emotion, 'recommendation_contents':recommendation_contents}
        return TemplateResponse(req, template='my_emotion.html', context=contexts, status=200)



# 감정리듬 뷰
import pandas as pd
@navsDecorator
def emotion_rhythm(req):
    if req.method == "GET":
        if not req.user.is_authenticated: # 로그인한 상태가 아니라면 로그인 페이지로 이동
            return redirect('signin')
        # 일기 하나라도 있는지 검사
        objs = DailyNote.objects.filter(user=req.user.id)
        # 없다면 달력으로 넘어감
        if not objs:
            return redirect('calendar')
        emotions = objs.values('emotion')
        df = pd.DataFrame(emotions).groupby('emotion').size()
        emotions_count = dict(df)
        contexts = {'emotions_count':emotions_count}
        return TemplateResponse(req, template='emotion_rhythm.html', context=contexts, status=200)



