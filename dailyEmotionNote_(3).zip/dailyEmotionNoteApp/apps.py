from django.apps import AppConfig


class dailyEmotionNoteAppConfig(AppConfig):
    name = 'dailyEmotionNoteApp'
