from hashlib import md5
import os
from .models import *
from django.core.paginator import Paginator
import time
import functools
from django.shortcuts import reverse
from .emotion import *

getNav = lambda url, name, *args, **kwargs: {"url": reverse(url, kwargs=kwargs), "name": name, 'url_name': url,
                                             'kwargs': kwargs}
make_salt = lambda: md5(os.urandom(128)).hexdigest()[:9]


def navsDecorator(function):
    @functools.wraps(function)
    def wrapper(*args, **kwargs):
        template = function(*args, **kwargs)
        try:
            year = timezone.localdate().year
            month = timezone.localdate().month
            day = timezone.localdate().day
            navs = [
                getNav('write_note', '일기쓰기', year=year, month=month, day=day),
                getNav('calendar', '감정달력'),
                getNav('my_emotion', '나의 감정은?'),
                getNav('emotion_rhythm', '감정리듬'),
                getNav('signup', '로그인') if args[0].user.is_anonymous else getNav('signout', '로그아웃'),
                getNav('signup', '회원가입')
            ]
            template.context_data['navs'] = navs
            return template.render()
        except Exception as e:
            print(e)
            return template
    return wrapper

from django.template.defaulttags import register
@register.filter
def get_range(value, arg):
    return range(arg+1,value+1)
@register.filter
def divide(value, arg):
    try:
        return (int(value) % int(7)) == arg+1
    except (ValueError, ZeroDivisionError):
        return None
@register.filter
def divide2(value, arg):
    try:
        return (int(value) % int(7)) == arg
    except (ValueError, ZeroDivisionError):
        return None