'''
각종 공통으로 쓰이는 기능들을 정의
'''
from config.config import pygame

def draw_block(screen, color, position):
    block = pygame.Rect(
        (position[1] * 20,
         position[0] * 20),
        (20, 20)
        )
    pygame.draw.rect(screen, color, block)
