'''
snake class에 대한 정의
'''
from config.config import screen, GREEN
from util.util import draw_block

class Snake:
    def __init__(self):
        self.positions = [(0,2), (0,1), (0,0)]
        self.direction = None

    def draw(self):
        for position in self.positions:
            draw_block(screen, GREEN, position)

    def move(self):
        head_position = self.positions[0]
        body_positions = self.positions[:-1]
        y, x = head_position

        if self.direction == 'N':
            new_position = [(y-1, x)]
        elif self.direction == 'S':
            new_position = [(y+1, x)]
        elif self.direction == 'W':
            new_position = [(y, x-1)]
        elif self.direction == 'E':
            new_position = [(y, x+1)]
        else:
            return

        self.positions = new_position + body_positions

    def grow(self):
        tail_position = self.positions[-1]
        y, x = tail_position

        if self.direction == 'N':
            new_position = [(y-1, x)]
        elif self.direction == 'S':
            new_position = [(y+1, x)]
        elif self.direction == 'W':
            new_position = [(y, x-1)]
        elif self.direction == 'E':
            new_position = [(y, x+1)]
        else:
            return

        self.positions.append(new_position[0])
        








        
