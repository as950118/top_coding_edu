'''
apple class에 관한 정의
'''
from config.config import screen, RED
from util.util import draw_block

class Apple:
    def __init__(self, position=(5,5)):
        self.position = position

    def draw(self):
        draw_block(screen, RED, self.position)
