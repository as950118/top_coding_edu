'''
각종 설정에 관한 정의
'''
import pygame
import random # 먹이의 랜덤한 위치를 위해
from datetime import datetime
from datetime import timedelta

# pygame 이니셜 라이징
pygame.init()

# 색에 관한 전역 변수
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)

# 사이즈에 관한 전역 변수
WIDTH = 400
HEIGHT = 400
size = [WIDTH, HEIGHT]

# 그밖에 것들
screen = pygame.display.set_mode(size)

done = False # 종료 여부(종료됐으면 True)
clock = pygame.time.Clock()
last_moved_time = datetime.now()

KEY_DIRECTION = {
    pygame.K_UP: 'N', # North
    pygame.K_DOWN: 'S', # South
    pygame.K_LEFT: 'W', # West
    pygame.K_RIGHT: 'E' # East
}


