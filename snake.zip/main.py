from util.util import draw_block
from character.snake import Snake
from character.apple import Apple
from config.config import *

def run_game():
    from config.config import done
    from config.config import last_moved_time    
    snake = Snake()
    apple = Apple()
    while not done:
        clock.tick(10)
        screen.fill(WHITE)

        # 방향설정에 관한 로직
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
            if event.type == pygame.KEYDOWN:
                if event.key in KEY_DIRECTION:
                    snake.direction = KEY_DIRECTION[event.key]

        # 뱀의 움직인에 관한 로직
        if timedelta(seconds=0.1) <= datetime.now() - last_moved_time:
            snake.move()
            last_moved_time = datetime.now()

        # 뱀이 사과를 먹었을때에 관한 로직
        if snake.positions[0] == apple.position:
            snake.grow()
            apple.position = (
                random.randint(0,19),
                random.randint(0,19)
                )

        # 뱀이 자기 몸에 부딪혔을때
        if snake.positions[0] in snake.positions[1:]:
            done = True

        snake.draw()
        apple.draw()
        pygame.display.update()

if __name__ == "__main__":
    run_game()
    pygame.quit()
