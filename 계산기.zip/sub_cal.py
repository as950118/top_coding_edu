'''
빼기까지 되는 계산기 만들기
'''
from cal import Cal

class SubCal(Cal):
    def sub(self, val):
        self.cur -= val


if __name__ == "__main__":
    cal = SubCal(10)
    cal.sub(4)
    cal.print()
    cal.clean()
    cal.print()
