'''
곱하기까지 되는 계산기
'''
from cal import Cal

class MulCal(Cal):
    def mul(self, val):
        self.cur *= val

if __name__ == "__main__":
    cal = MulCal(5)
    cal.mul(4)
    cal.print()
