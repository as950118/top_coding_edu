'''
더하기가 되는 계산기
'''
from cal import Cal

class AddCal(Cal):
    def add(self, val):
        self.cur += val
