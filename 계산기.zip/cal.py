'''
클래스로 계산기 구현하기
상속을 활용해서 다양한 계산기 만들기
그냥 숫자가 입력이 되는 계산기
-> 더하기가 되는 계산기
-> + 빼기가 되는 계산기
-> + 곱하기가 되는 계산기
-> + 나누기가 되는 계산기
-> 기타 등등..
'''
# 가장 기본이 되는 계산기
class Cal:
    def __init__(self, init=0): # 초기설정값
        self.cur = init # 현재값

    def print(self):
        print(self.cur)

    def clean(self):
        self.cur = 0

    def set(self, val):
        self.cur = val


















