'''
나누기까지 되는 계산기
'''
from cal import Cal

class DivCal(Cal):
    def div(self, val):
        self.cur /= val

if __name__ == "__main__":
    cal = DivCal(5)
    cal.add(5)
    cal.sub(3)
    cal.mul(7)
    cal.div(2)
    cal.print()
