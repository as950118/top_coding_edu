'''
4개의  사칙연산을 상속받는 계산기
'''
from add_cal import AddCal
from sub_cal import SubCal
from mul_cal import MulCal
from div_cal import DivCal


class FourCal(AddCal, SubCal, MulCal, DivCal):
    pass

if __name__ == "__main__":
    cal = FourCal()
    cal.add(5)
    cal.print()
    cal.sub(3)
    cal.print()
    cal.mul(7)
    cal.print()
    cal.div(3)
    cal.print()
